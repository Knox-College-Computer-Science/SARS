import { io } from "socket.io-client";

// Create one socket instance for the whole app.
// autoConnect: false means we connect manually when the user is ready.
const socket = io("http://localhost:8000", {
  autoConnect: false,
  transports: ["websocket", "polling"],
});

export default socket;
