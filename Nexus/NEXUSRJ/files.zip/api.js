const BASE = "http://localhost:8000";

async function req(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail ?? `Request failed: ${res.status}`);
  }
  return res.json();
}

// ---- Channel messages ----

export function fetchChannelMessages(channelId) {
  return req(`/channels/${channelId}/messages?limit=50`);
}

export function postChannelMessage(channelId, content, senderId) {
  return req(`/channels/${channelId}/messages`, {
    method: "POST",
    body: JSON.stringify({ content, sender_id: senderId }),
  });
}

// ---- Conversations (DMs) ----

export function getOrCreateConversation(senderId, recipientId) {
  return req("/conversations", {
    method: "POST",
    body: JSON.stringify({ sender_id: senderId, recipient_id: recipientId }),
  });
}

export function fetchDMMessages(conversationId) {
  return req(`/conversations/${conversationId}/messages?limit=50`);
}

export function postDM(conversationId, content, senderId) {
  return req(`/conversations/${conversationId}/messages`, {
    method: "POST",
    body: JSON.stringify({ content, sender_id: senderId }),
  });
}

// ---- Auth (seed the test user so backend has them in DB) ----

export function seedTestUser() {
  return req("/auth/school-launch", {
    method: "POST",
    body: JSON.stringify({ course_id: "CHEM101", token: "test" }),
  });
}
