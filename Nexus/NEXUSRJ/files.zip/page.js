"use client";

import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import ChatArea from "@/components/ChatArea";
import DMArea from "@/components/DMArea";
import { seedTestUser } from "@/lib/api";

// The current logged-in user.
// Later this comes from the JWT after school OAuth.
const CURRENT_USER = {
  id:         "user-001",
  name:       "You",
  initials:   "YO",
  avatarBg:   "#E6F1FB",
  avatarText: "#185FA5",
};

export default function CoursePage({ params }) {
  const { courseId } = params;
  const [activeView,    setActiveView]    = useState({ type: "channel", id: "general" });
  const [channelMap,    setChannelMap]    = useState({});  // channelName -> DB id
  const [backendReady,  setBackendReady]  = useState(false);

  const course = {
    id:      courseId,
    name:    "Introduction to Chemistry",
    code:    courseId,
    teacher: "Dr. Martinez",
  };

  // On mount: seed the test user in the DB so the backend knows who "user-001" is
  useEffect(() => {
    seedTestUser()
      .then(() => setBackendReady(true))
      .catch(() => {
        // Backend not running — still show UI with local state
        setBackendReady(false);
      });
  }, []);

  // When the user selects a channel, look up its DB ID from channelMap
  const activeChannelDbId = activeView.type === "channel"
    ? channelMap[activeView.id] ?? null
    : null;

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      <Sidebar
        course={course}
        activeView={activeView}
        onSelectChannel={(id) => setActiveView({ type: "channel", id })}
        onSelectDM={(id)      => setActiveView({ type: "dm",      id })}
      />

      {activeView.type === "channel" ? (
        <ChatArea
          channelId={activeView.id}
          channelDbId={activeChannelDbId}
          currentUser={CURRENT_USER}
        />
      ) : (
        <DMArea
          recipientId={activeView.id}
          currentUser={CURRENT_USER}
        />
      )}
    </div>
  );
}
