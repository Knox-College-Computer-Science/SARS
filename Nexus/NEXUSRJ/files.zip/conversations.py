from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc, and_
from pydantic import BaseModel
from typing import Optional

from database import get_db
from models import Conversation, ConversationParticipant, DirectMessage, User, CourseEnrollment
from socket_manager import sio

router = APIRouter()


class StartConversation(BaseModel):
    sender_id:    str
    recipient_id: str


class SendDM(BaseModel):
    content:   str
    sender_id: str


# ------------------------------------------------------------------
# POST /conversations
# Find existing conversation or create a new one
# ------------------------------------------------------------------
@router.post("")
def get_or_create_conversation(body: StartConversation, db: Session = Depends(get_db)):
    # Find a conversation both users share
    sender_convs = (
        db.query(ConversationParticipant.conversation_id)
        .filter(ConversationParticipant.user_id == body.sender_id)
        .subquery()
    )
    shared = (
        db.query(ConversationParticipant.conversation_id)
        .filter(
            ConversationParticipant.user_id == body.recipient_id,
            ConversationParticipant.conversation_id.in_(sender_convs),
        )
        .first()
    )

    if shared:
        conv = db.query(Conversation).filter(Conversation.id == shared[0]).first()
    else:
        # Create a new conversation
        conv = Conversation()
        db.add(conv)
        db.flush()
        db.add(ConversationParticipant(conversation_id=conv.id, user_id=body.sender_id))
        db.add(ConversationParticipant(conversation_id=conv.id, user_id=body.recipient_id))
        db.commit()
        db.refresh(conv)

    recipient = db.query(User).filter(User.id == body.recipient_id).first()
    return {
        "conversation_id": conv.id,
        "recipient_name":     recipient.display_name if recipient else "Unknown",
        "recipient_initials": recipient.initials     if recipient else "??",
    }


# ------------------------------------------------------------------
# GET /conversations/{id}/messages
# ------------------------------------------------------------------
@router.get("/{conversation_id}/messages")
def get_dm_messages(conversation_id: str, limit: int = 50, db: Session = Depends(get_db)):
    rows = (
        db.query(DirectMessage)
        .filter(
            DirectMessage.conversation_id == conversation_id,
            DirectMessage.deleted_at == None,
        )
        .order_by(desc(DirectMessage.sent_at))
        .limit(limit)
        .all()
    )
    rows.reverse()

    result = []
    for m in rows:
        sender = db.query(User).filter(User.id == m.sender_id).first()
        result.append({
            "id":              m.id,
            "conversation_id": m.conversation_id,
            "sender_id":       m.sender_id,
            "sender_name":     sender.display_name if sender else "Unknown",
            "sender_initials": sender.initials     if sender else "??",
            "content":         m.content,
            "sent_at":         m.sent_at.strftime("%I:%M %p") if m.sent_at else "",
        })
    return {"messages": result}


# ------------------------------------------------------------------
# POST /conversations/{id}/messages
# Save DM and broadcast to conversation room
# ------------------------------------------------------------------
@router.post("/{conversation_id}/messages", status_code=201)
async def send_dm(conversation_id: str, body: SendDM, db: Session = Depends(get_db)):
    if not body.content.strip():
        raise HTTPException(400, "Empty message")

    sender = db.query(User).filter(User.id == body.sender_id).first()
    if not sender:
        raise HTTPException(404, "User not found")

    msg = DirectMessage(
        conversation_id=conversation_id,
        sender_id=body.sender_id,
        content=body.content.strip(),
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)

    payload = {
        "id":              msg.id,
        "conversation_id": msg.conversation_id,
        "sender_id":       msg.sender_id,
        "sender_name":     sender.display_name,
        "sender_initials": sender.initials,
        "content":         msg.content,
        "sent_at":         msg.sent_at.strftime("%I:%M %p") if msg.sent_at else "",
    }

    await sio.emit("new_dm", payload, room=f"conversation:{conversation_id}")
    return payload
