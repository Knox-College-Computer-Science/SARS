"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Message from "./Message";
import styles from "./ChatArea.module.css";
import socket from "@/lib/socket";
import { getOrCreateConversation, fetchDMMessages, postDM } from "@/lib/api";

const DM_CONTACTS = {
  "user-002": { name: "Sarah Johnson",  initials: "SJ" },
  "user-003": { name: "Marcus Lee",     initials: "ML" },
  "user-004": { name: "Priya Kumar",    initials: "PK" },
  "user-005": { name: "James Okonkwo",  initials: "JO" },
};

const SEED_DMS = {
  "user-002": [
    { id: "d1", senderId: "user-002", senderName: "Sarah Johnson", senderInitials: "SJ", colorIndex: 0, content: "Hey! Are you coming to the study session tomorrow?", sentAt: "Yesterday" },
    { id: "d2", senderId: "user-001", senderName: "You", senderInitials: "YO", colorIndex: -1, content: "Yes! What time does it start?", sentAt: "Yesterday" },
    { id: "d3", senderId: "user-002", senderName: "Sarah Johnson", senderInitials: "SJ", colorIndex: 0, content: "3 PM in the library, room 204.", sentAt: "Yesterday" },
  ],
  "user-003": [
    { id: "d4", senderId: "user-003", senderName: "Marcus Lee", senderInitials: "ML", colorIndex: 1, content: "Did you get the notes from Thursday? I was sick.", sentAt: "Monday" },
  ],
  "user-004": [],
  "user-005": [],
};

function SendIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  );
}

export default function DMArea({ recipientId, currentUser }) {
  const [messages,       setMessages]       = useState(SEED_DMS[recipientId] ?? []);
  const [input,          setInput]          = useState("");
  const [sending,        setSending]        = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const bottomRef = useRef(null);
  const inputRef  = useRef(null);

  const recipient = DM_CONTACTS[recipientId] ?? { name: "Unknown", initials: "??" };

  // When recipient changes: resolve the conversation, load history, join socket room
  useEffect(() => {
    setMessages(SEED_DMS[recipientId] ?? []);
    setInput("");
    setConversationId(null);

    // Leave previous room
    if (conversationId) socket.emit("leave_conversation", { conversation_id: conversationId });

    // Get or create conversation with this recipient
    getOrCreateConversation(currentUser.id, recipientId)
      .then(data => {
        const convId = data.conversation_id;
        setConversationId(convId);
        socket.emit("join_conversation", { conversation_id: convId });

        // Load real message history
        return fetchDMMessages(convId);
      })
      .then(data => {
        if (data.messages.length > 0) setMessages(data.messages);
      })
      .catch(console.error);
  }, [recipientId, currentUser.id]);

  // Listen for incoming DMs
  useEffect(() => {
    function onNewDM(msg) {
      if (msg.conversation_id !== conversationId) return;
      setMessages(prev => {
        if (prev.find(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
    }
    socket.on("new_dm", onNewDM);
    return () => socket.off("new_dm", onNewDM);
  }, [conversationId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleInput = useCallback((e) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 130) + "px";
  }, []);

  const handleKey = useCallback((e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }, [input]);

  async function send() {
    const text = input.trim();
    if (!text || sending || !conversationId) return;

    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const tempId = `temp-${Date.now()}`;

    setMessages(prev => [...prev, {
      id: tempId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderInitials: currentUser.initials,
      colorIndex: -1,
      content: text,
      sentAt: now,
    }]);
    setInput("");
    if (inputRef.current) inputRef.current.style.height = "auto";

    setSending(true);
    try {
      const saved = await postDM(conversationId, text, currentUser.id);
      setMessages(prev => prev.map(m => m.id === tempId ? { ...saved, colorIndex: -1 } : m));
    } catch (err) {
      console.error("DM send failed:", err);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.channelName}>{recipient.name}</span>
        <span className={styles.meta}>· Direct message</span>
      </div>

      <div className={styles.feed}>
        {messages.length === 0 && (
          <p className={styles.empty}>Start a conversation with {recipient.name}</p>
        )}
        {messages.map(msg => (
          <Message
            key={msg.id}
            msg={msg}
            isOwn={msg.senderId === currentUser.id}
            currentUser={currentUser}
          />
        ))}
        <div ref={bottomRef} />
      </div>

      <div className={styles.inputRow}>
        <textarea
          ref={inputRef}
          className={styles.input}
          placeholder={`Message ${recipient.name}`}
          value={input}
          onChange={handleInput}
          onKeyDown={handleKey}
          rows={1}
          disabled={sending || !conversationId}
        />
        <button
          className={styles.sendBtn}
          onClick={send}
          disabled={!input.trim() || sending || !conversationId}
        >
          <SendIcon />
        </button>
      </div>
    </div>
  );
}
