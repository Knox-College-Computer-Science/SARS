from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc
from pydantic import BaseModel
from typing import Optional

from database import get_db
from models import ChannelMessage, Channel, User
from socket_manager import sio

router = APIRouter()


class SendMsg(BaseModel):
    content: str
    sender_id: str
    reply_to_id: Optional[str] = None


@router.get("/channels/{channel_id}/messages")
def get_messages(channel_id: str, limit: int = 50, db: Session = Depends(get_db)):
    channel = db.query(Channel).filter(Channel.id == channel_id).first()
    if not channel:
        raise HTTPException(404, "Channel not found")

    rows = (
        db.query(ChannelMessage)
        .filter(ChannelMessage.channel_id == channel_id, ChannelMessage.deleted_at == None)
        .order_by(desc(ChannelMessage.sent_at))
        .limit(limit)
        .all()
    )
    rows.reverse()

    result = []
    for m in rows:
        sender = db.query(User).filter(User.id == m.sender_id).first()
        result.append({
            "id":              m.id,
            "channel_id":      m.channel_id,
            "sender_id":       m.sender_id,
            "sender_name":     sender.display_name if sender else "Unknown",
            "sender_initials": sender.initials     if sender else "??",
            "content":         m.content,
            "sent_at":         m.sent_at.strftime("%I:%M %p") if m.sent_at else "",
        })
    return {"messages": result, "has_more": len(result) == limit}


@router.post("/channels/{channel_id}/messages", status_code=201)
async def send_message(channel_id: str, body: SendMsg, db: Session = Depends(get_db)):
    if not body.content.strip():
        raise HTTPException(400, "Empty message")
    if len(body.content) > 2000:
        raise HTTPException(400, "Too long")

    channel = db.query(Channel).filter(Channel.id == channel_id).first()
    if not channel:
        raise HTTPException(404, "Channel not found")

    sender = db.query(User).filter(User.id == body.sender_id).first()
    if not sender:
        raise HTTPException(404, "User not found")

    msg = ChannelMessage(
        channel_id=channel_id,
        sender_id=body.sender_id,
        content=body.content.strip(),
        reply_to_id=body.reply_to_id,
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)

    payload = {
        "id":              msg.id,
        "channel_id":      msg.channel_id,
        "sender_id":       msg.sender_id,
        "sender_name":     sender.display_name,
        "sender_initials": sender.initials,
        "content":         msg.content,
        "sent_at":         msg.sent_at.strftime("%I:%M %p") if msg.sent_at else "",
    }

    await sio.emit("new_channel_message", payload, room=f"channel:{channel_id}")
    return payload
