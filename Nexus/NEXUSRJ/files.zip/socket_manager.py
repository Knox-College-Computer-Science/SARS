import socketio

# This is the single Socket.io server instance.
# It's imported by main.py and routes so they all share the same instance.
sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins=["http://localhost:3000"],
    logger=False,
    engineio_logger=False,
)

# ----------------------------------------------------------------
# Connection events
# ----------------------------------------------------------------

@sio.event
async def connect(sid, environ, auth):
    print(f"[socket] client connected: {sid}")

@sio.event
async def disconnect(sid):
    print(f"[socket] client disconnected: {sid}")

# ----------------------------------------------------------------
# Room events — client calls these to subscribe to a channel or DM
# ----------------------------------------------------------------

@sio.event
async def join_channel(sid, data):
    """Client emits this when they open a channel."""
    room = f"channel:{data['channel_id']}"
    await sio.enter_room(sid, room)
    print(f"[socket] {sid} joined room {room}")

@sio.event
async def leave_channel(sid, data):
    room = f"channel:{data['channel_id']}"
    await sio.leave_room(sid, room)

@sio.event
async def join_conversation(sid, data):
    """Client emits this when they open a DM conversation."""
    room = f"conversation:{data['conversation_id']}"
    await sio.enter_room(sid, room)
    print(f"[socket] {sid} joined room {room}")

@sio.event
async def leave_conversation(sid, data):
    room = f"conversation:{data['conversation_id']}"
    await sio.leave_room(sid, room)

# ----------------------------------------------------------------
# Typing indicators
# ----------------------------------------------------------------

@sio.event
async def typing_start(sid, data):
    room = f"channel:{data['channel_id']}"
    await sio.emit("user_typing", {"name": data.get("name", "Someone")}, room=room, skip_sid=sid)

@sio.event
async def typing_stop(sid, data):
    room = f"channel:{data['channel_id']}"
    await sio.emit("user_stopped_typing", {}, room=room, skip_sid=sid)
