"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Message from "./Message";
import styles from "./ChatArea.module.css";
import socket from "@/lib/socket";
import { fetchChannelMessages, postChannelMessage } from "@/lib/api";

// Seed data shown before any DB messages load, per channel
const SEED = {
  general: [
    { id: "s1", senderId: "user-002", senderName: "Sarah Johnson",  senderInitials: "SJ", colorIndex: 0, content: "Hey everyone! Does anyone understand question 3 on the homework?", sentAt: "2:14 PM" },
    { id: "s2", senderId: "user-003", senderName: "Marcus Lee",     senderInitials: "ML", colorIndex: 1, content: "Yeah — use the ideal gas law. PV = nRT. What values did you get for P and T?", sentAt: "2:17 PM" },
    { id: "s3", senderId: "user-002", senderName: "Sarah Johnson",  senderInitials: "SJ", colorIndex: 0, content: "P = 2.5 atm, T = 300 K. I got n = 0.10 mol but the key says 0.102.", sentAt: "2:19 PM" },
  ],
  announcements: [
    { id: "s4", senderId: "teacher", senderName: "Dr. Martinez", senderInitials: "DM", colorIndex: 3, content: "Lab report due Friday 11:59 PM — submit through the course portal.", sentAt: "9:00 AM" },
    { id: "s5", senderId: "teacher", senderName: "Dr. Martinez", senderInitials: "DM", colorIndex: 3, content: "Office hours moved to Thursday 3–5 PM this week.", sentAt: "9:03 AM" },
  ],
  "homework-help": [
    { id: "s6", senderId: "user-004", senderName: "Priya Kumar", senderInitials: "PK", colorIndex: 2, content: "Can someone explain what a limiting reagent is in plain terms?", sentAt: "1:30 PM" },
    { id: "s7", senderId: "user-003", senderName: "Marcus Lee",  senderInitials: "ML", colorIndex: 1, content: "Think of it like a recipe — it's the ingredient that runs out first.", sentAt: "1:34 PM" },
  ],
  "lab-partners": [
    { id: "s8", senderId: "user-002", senderName: "Sarah Johnson", senderInitials: "SJ", colorIndex: 0, content: "Looking for a lab partner for next Tuesday! Anyone free?", sentAt: "11:00 AM" },
  ],
};

function SendIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  );
}

export default function ChatArea({ channelId, channelDbId, currentUser }) {
  const [messages,   setMessages]   = useState(SEED[channelId] ?? []);
  const [input,      setInput]      = useState("");
  const [sending,    setSending]    = useState(false);
  const [typingUser, setTypingUser] = useState(null);
  const [connected,  setConnected]  = useState(false);
  const bottomRef  = useRef(null);
  const inputRef   = useRef(null);
  const typingRef  = useRef(null);

  // Connect socket once
  useEffect(() => {
    if (!socket.connected) socket.connect();

    function onConnect()    { setConnected(true);  }
    function onDisconnect() { setConnected(false); }

    socket.on("connect",    onConnect);
    socket.on("disconnect", onDisconnect);
    if (socket.connected) setConnected(true);

    return () => {
      socket.off("connect",    onConnect);
      socket.off("disconnect", onDisconnect);
    };
  }, []);

  // Join/leave channel room + load history when channelId changes
  useEffect(() => {
    setMessages(SEED[channelId] ?? []);
    setInput("");
    setTypingUser(null);

    // If we have a DB channel ID, load real messages from backend
    if (channelDbId) {
      fetchChannelMessages(channelDbId)
        .then(data => {
          if (data.messages.length > 0) {
            setMessages(data.messages);
          }
        })
        .catch(console.error);
    }

    // Join the socket room for this channel
    if (channelDbId) {
      socket.emit("join_channel", { channel_id: channelDbId });
    }

    return () => {
      if (channelDbId) {
        socket.emit("leave_channel", { channel_id: channelDbId });
      }
    };
  }, [channelId, channelDbId]);

  // Listen for incoming messages from other users
  useEffect(() => {
    function onNewMessage(msg) {
      // Don't add if it's our own message (we already added it optimistically)
      setMessages(prev => {
        if (prev.find(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
    }

    function onUserTyping(data) {
      setTypingUser(data.name);
      clearTimeout(typingRef.current);
      typingRef.current = setTimeout(() => setTypingUser(null), 3000);
    }

    function onUserStoppedTyping() {
      setTypingUser(null);
    }

    socket.on("new_channel_message", onNewMessage);
    socket.on("user_typing",         onUserTyping);
    socket.on("user_stopped_typing", onUserStoppedTyping);

    return () => {
      socket.off("new_channel_message", onNewMessage);
      socket.off("user_typing",         onUserTyping);
      socket.off("user_stopped_typing", onUserStoppedTyping);
    };
  }, []);

  // Always scroll to bottom when messages change
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typingUser]);

  const handleInput = useCallback((e) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 130) + "px";

    // Tell others this user is typing
    if (channelDbId) {
      socket.emit("typing_start", { channel_id: channelDbId, name: currentUser.name });
    }
  }, [channelDbId, currentUser.name]);

  const handleKey = useCallback((e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }, [input]);

  async function send() {
    const text = input.trim();
    if (!text || sending) return;

    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    // Optimistic update — show immediately
    const tempId = `temp-${Date.now()}`;
    const optimistic = {
      id:             tempId,
      senderId:       currentUser.id,
      senderName:     currentUser.name,
      senderInitials: currentUser.initials,
      colorIndex:     -1,
      content:        text,
      sentAt:         now,
    };
    setMessages(prev => [...prev, optimistic]);
    setInput("");
    if (inputRef.current) inputRef.current.style.height = "auto";

    // Tell server typing stopped
    if (channelDbId) socket.emit("typing_stop", { channel_id: channelDbId });

    // Save to database (only if we have a real channel DB ID)
    if (channelDbId) {
      setSending(true);
      try {
        const saved = await postChannelMessage(channelDbId, text, currentUser.id);
        // Replace temp message with the real one from DB (has real ID)
        setMessages(prev => prev.map(m => m.id === tempId ? { ...saved, colorIndex: -1 } : m));
      } catch (err) {
        console.error("Failed to save message:", err);
        // Mark the message as failed
        setMessages(prev => prev.map(m =>
          m.id === tempId ? { ...m, failed: true } : m
        ));
      } finally {
        setSending(false);
      }
    }
  }

  const isAnnouncements = channelId === "announcements";

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <span className={styles.hash}>#</span>
        <span className={styles.channelName}>{channelId}</span>
        <span className={styles.meta}>· 24 members</span>
        {connected && <span className={styles.liveTag}>live</span>}
      </div>

      <div className={styles.feed}>
        {messages.length === 0 && (
          <p className={styles.empty}>No messages yet. Start the conversation!</p>
        )}
        {messages.map(msg => (
          <Message
            key={msg.id}
            msg={msg}
            isOwn={msg.senderId === currentUser.id}
            currentUser={currentUser}
          />
        ))}

        {typingUser && (
          <div className={styles.typing}>
            <span className={styles.dot} />
            <span className={styles.dot} />
            <span className={styles.dot} />
            <span className={styles.typingLabel}>{typingUser} is typing…</span>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {isAnnouncements ? (
        <div className={styles.readOnly}>
          Only teachers can post in announcements
        </div>
      ) : (
        <div className={styles.inputRow}>
          <textarea
            ref={inputRef}
            className={styles.input}
            placeholder={`Message #${channelId}`}
            value={input}
            onChange={handleInput}
            onKeyDown={handleKey}
            rows={1}
            disabled={sending}
          />
          <button
            className={styles.sendBtn}
            onClick={send}
            disabled={!input.trim() || sending}
            title="Send (Enter)"
          >
            <SendIcon />
          </button>
        </div>
      )}
    </div>
  );
}
